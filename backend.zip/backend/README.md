ADD YOUR OWN .ENV FILE BASED ON YOUR MYSQL WORKBENCH, USE EXAMPLE.env AS BASIS

**INSTALLED COMMANDS**
- npm install express mysql2 dotenv bcrypt
- npm i -D nodemon


**RUN SQL SCHEMA QUERY**
- [IN TERMINAL]
- open terminal
- cd backend 
- npm run initdb


**TO CHECK PROGRESS IN LOCALHOST**
- [IN TERMINAL]
- open terminal
- cd backend
- npm run dev