function Home() {
  return (
    <div style={{ textAlign: 'center', marginTop: '2rem' }}>
      <h1>Test Test</h1>
      <p>working in progress! go back to /login!</p>
    </div>
  );
}

export default Home;