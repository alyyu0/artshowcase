**INSTALLED COMMANDS**
- npm install react-bootstrap bootstrap
- npm install lucide-react
- npm install react-bootstrap-icons


**TO CHECK PROGRESS IN LOCALHOST**
- [IN TERMINAL]
- open terminal
- cd frontend
- npm run dev